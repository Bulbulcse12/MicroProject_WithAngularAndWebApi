export interface Information{
    id: number;
    name : string;
    department : string;
}