import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Information } from 'src/app/models/information.model';
import { StudentsService } from 'src/app/services/students.service';

@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css']
})
export class EditStudentComponent implements OnInit{
  studentDetails:Information = {
    name: '',
    department: '',
    id: 0
  };

  constructor(private route:ActivatedRoute,private studentService:StudentsService,private router:Router){}
  ngOnInit(): void {
    this.route.paramMap.subscribe({
      next:(params)=>{
        const id =params.get('id') ?? '';
        //const id =parseInt(num);
        if(id){
          this.studentService.getStudent(parseInt(id))
          .subscribe({
            next:(response)=>{
              this.studentDetails = response;
            }
          })
        }
      }
    })
  }
  updateStudent(){
    this.studentService.updateStudent(this.studentDetails.id,this.studentDetails)
    .subscribe({
      next:(response)=>{
        this.router.navigate(['employees']);
      },
      error: (response) =>{
        console.log(response);
      }
    })
  }

  deleteStudent(id:number){
    this.studentService.deleteStudent(id)
    .subscribe({
      next:(response)=>{
        this.router.navigate(['employees']);
      },
      error: (response) =>{
        console.log(response);
      }
    })
  }
}


