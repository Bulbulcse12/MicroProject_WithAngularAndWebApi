import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Information } from 'src/app/models/information.model';
import { StudentsService } from 'src/app/services/students.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit{

  students:Information = {
    name: '',
    department: '',
    id: 0
  };
  constructor(private studentService:StudentsService,private router:Router){}
  ngOnInit(): void {

  }

  addStudent(){
   this.studentService.addStudent(this.students)
   .subscribe({
    next: (students) => {
      //console.log(students);
     //this.students = students;
     this.router.navigate([ students ])
    },
    error: (response) =>{
      console.log(response);
    }
   });
  }

}