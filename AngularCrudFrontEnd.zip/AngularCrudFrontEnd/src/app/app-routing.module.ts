import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEmployeeComponent } from './Components/Students/add-employee/add-employee.component';
import { EditStudentComponent } from './Components/Students/edit-student/edit-student.component';
import { StudentListComponent } from './Components/Students/student-list/student-list.component';

const routes: Routes = [
  {
    path : '',
    component : StudentListComponent
  },
  {
    path : 'employees',
    component : StudentListComponent
  },
  {
    path : 'employees/add',
    component : AddEmployeeComponent
  },
  {
    path : 'employees/edit/:id',
    component : EditStudentComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
