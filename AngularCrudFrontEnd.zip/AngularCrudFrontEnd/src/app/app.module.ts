import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentListComponent } from './Components/Students/student-list/student-list.component';
import { AddEmployeeComponent } from './Components/Students/add-employee/add-employee.component';
import { FormsModule } from '@angular/forms';
import { EditStudentComponent } from './Components/Students/edit-student/edit-student.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentListComponent,
    AddEmployeeComponent,
    EditStudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
