import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { environment } from 'src/environments/environment';
import { Information } from '../models/information.model';

@Injectable({
  providedIn: 'root'
})
export class StudentsService {
 
  //baseApiUrl: string = environment.baseApiUrl;
  baseUrl:string = 'https://localhost:7183'

  constructor(private http:HttpClient) { }

  getAllStudents(): Observable<Information[]>{
    return this.http.get<Information[]>(this.baseUrl + '/api/Students/GetStudent');
  }

  addStudent(addStudentsReq:Information): Observable<Information>{
   return this.http.post<Information>(this.baseUrl + '/api/Students/AddStudent',addStudentsReq);
  }

  getStudent(id:number): Observable<Information>{
    return this.http.get<Information>(this.baseUrl + '/api/Students/' + id);
   }

   updateStudent(id:number,updateStudentReq:Information){
    return this.http.put<Information>(this.baseUrl + '/api/Students/UpdateStudent/' + id,
    updateStudentReq);
   }
   deleteStudent(id:number):Observable<Information>{
    return this.http.delete<Information>(this.baseUrl + '/api/Students/DeleteStudent/' + id);
   }
}
