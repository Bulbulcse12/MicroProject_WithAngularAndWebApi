export const environment = {
    production: true,
    baseApiUrl: "https://localhost:7183"
};
