﻿using angularCrud.Data;
using angularCrud.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;

namespace angularCrud.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public StudentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("GetStudent")]
        public async Task<IEnumerable<Informations>> GetStudents()
        {
            var result = _context.Information.ToList();
            return result;
        }

        [HttpGet]
        [Route("{id:int}")]
        public async Task<Informations> GetStudentById(int id)
        {
            var result = _context.Information.FirstOrDefault(x => x.Id == id);
         
            return result;
            
            
        }

        [HttpPost]
        [Route("AddStudent")]
        public async Task<Informations> AddStudent(Informations info)
        {
           _context.Information.Add(info);
           await _context.SaveChangesAsync(); 
            return info;

        }

        [HttpPut]
        [Route("UpdateStudent/{id:int}")]
        public async Task<IActionResult> UpdateStudents([FromRoute] int id,Informations info)
        {
            //_context.Information.Entry(info).State = EntityState.Modified;
            //await _context.SaveChangesAsync();
            //return info;

            var student = _context.Information.Find(id);
            if (student == null)
            {
                return NotFound();
            }
            student.Name = info.Name;
            student.Department = info.Department;
            _context.SaveChanges();
            return Ok(student);
        }

        [HttpDelete]
        [Route("DeleteStudent/{id:int}")]
        public async Task<IActionResult> DeleteStudent([FromRoute] int id)
        {
            //bool a = false;
            //var student = _context.Information.Find(id);
            //if(student != null)
            //{
            //    a = true;
            //    _context.Information.Entry(student).State = EntityState.Deleted;
            //    _context.SaveChanges();
            //}
            //else
            //{
            //    a = false;
            //}
            //return a;
            var student = _context.Information.Find(id);
            if(student == null)
            {
                return NotFound();
            }

            _context.Information.Remove(student);
            _context.SaveChanges();
            return Ok();

        }
    }
}
