﻿using angularCrud.Models;
using Microsoft.EntityFrameworkCore;

namespace angularCrud.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        public DbSet<Informations> Information { get; set; }
    }
}
